--[[
AddMusic(SectorX,SectorY,SectorZ,MusicType,MusicID)

MusicType :
1 - standard music, sector no enemy (NOTHING_xxx.wav or NOTHING_xxx.ogg)
2 - enemy in sector  (TENSOR_xxx.wav or TENSOR_xxx.ogg)
3 - start battle  (BATTLE_xxx.wav or BATTLE_xxx.ogg)
4 - victory  (TRIUMPH_xxx.wav or TRIUMPH_xxx.ogg)
5 - death merc  (DEATH_xxx.wav or DEATH_xxx.ogg)

xxx - number file

MusicID - id of music

Put to "Music" folder ogg or wav file. We number the names of files NOTHING_0.wav... NOTHING_10.wav ... etc



Example :

AddMusic(1,10,0,1,0) -- add to sector A10, music type "1" and file NOTHING_0.wav or NOTHING_0.ogg.
AddMusic(1,10,1,1,0) -- add to sector A10_B1, music type "1" and file NOTHING_0.wav or NOTHING_0.ogg.

AddMusic(1,9,0,2,10) -- add to sector A9, music type "2" and file TENSOR_10.wav or TENSOR_10.ogg.


for x = 1,16 do
	for y = 1,16 do
		AddMusic(x,y,0,1,10) -- add to all sector, music type "1" and file NOTHING_10.wav or NOTHING_10.ogg.
	end
end

]]

SectorY = 
{
	MAP_ROW_A = 1,
	MAP_ROW_B = 2,
	MAP_ROW_C = 3,
	MAP_ROW_D = 4,
	MAP_ROW_E = 5,
	MAP_ROW_F = 6,
	MAP_ROW_G = 7,
	MAP_ROW_H = 8,
	MAP_ROW_I = 9,
	MAP_ROW_J = 10,
	MAP_ROW_K = 11,
	MAP_ROW_L = 12,
	MAP_ROW_M = 13,
	MAP_ROW_N = 14,
	MAP_ROW_O = 15,
	MAP_ROW_P = 16,
}

function Music()
	AddMusic(9,SectorY.MAP_ROW_A,0,1,2)  -- music nothing
	AddMusic(10,SectorY.MAP_ROW_A,0,1,2) -- music nothing
	AddMusic(10,SectorY.MAP_ROW_A,1,1,1) -- music nothing
	
	AddMusic(10,SectorY.MAP_ROW_A,0,3,0)  -- Muisc Battle
	AddMusic(9,SectorY.MAP_ROW_A,0,3,0)   -- Muisc Battle
	AddMusic(10,SectorY.MAP_ROW_A,1,3,1)  -- Muisc Battle
end