**************************************************************************************************************************
Apply this fix if you want to play Jagged Alliance 2 v1.13 on Windows 8 and the game does not start / runs extremely slow
**************************************************************************************************************************

1. Edit the 'Ja2.ini' file in your Jagged Alliance 2 v1.13 Installation directory
   -> Set PLAY_INTRO = 0, save the file and close it
2. Right click on the JA2 1.13 executable (ja2.exe), edit the properties and check the "Compatibility" mode
   -> Check the "XP SP3" compatibility mode
3. Set the Windows 8 color mode to 16 bit
4. Run the game (ja2.exe) as Windows 8 Administrator

If all else fails, try this extra step:
5. Copy the content of the "GameDir" folder in your Jagged Alliance 2 v1.13 Installation directory

References:
http://www.ja-galaxy-forum.com/board/ubbthreads.php/topics/312897/Jagged_Alliance_2_on_Windows_8.html
http://www.bears-pit.com/board/ubbthreads.php/topics/315860/Win_8.html#Post315860
