**************************************************************************************************************
Apply this fix if playing Jagged Alliance 2 v1.13 on Windows 8/8.1 does not start / runs extremely slow
**************************************************************************************************************

1. Edit the 'Ja2.ini' file in your Jagged Alliance 2 v1.13 Installation directory
   -> Set SCREEN_MODE_WINDOWED = 1
   -> Set PLAY_INTRO = 0, save and close the file
2. Right click on the JA2 1.13 executable (ja2.exe), edit the properties and check the "Compatibility" mode
   -> Check the "Reduced color mode" to 16-bit

If the above fails, try the following:
- Run the game (ja2.exe) as Windows 8 Administrator
- Right click on the JA2 1.13 executable (ja2.exe), edit the properties and check the "Compatibility" mode
   -> Check the "XP SP3" compatibility mode
- Copy the contents of the "GameDir" folder to your Jagged Alliance 2 v1.13 Installation directory

** Additional Windows 8 Registry Fix **
1. Edit the "Win8RegistryFix.reg" file inside your JA2 1.13 installation directory with notepad and change the path to the ja2.exe file
2. Save and close the file
3. Double click the "Win8RegistryFix.reg" file to alter the Windows 8 Registry

References:
http://www.ja-galaxy-forum.com/board/ubbthreads.php/topics/312897/Jagged_Alliance_2_on_Windows_8.html
http://www.bears-pit.com/board/ubbthreads.php/topics/315860/Win_8.html#Post315860
http://www.ja-galaxy-forum.com/ubbthreads.php/topics/335812/1