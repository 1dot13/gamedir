**************************************************************************************************************
Apply the fixes if you play Jagged Alliance 2 v1.13 on Windows 8/8.1 or Windows 10 does not start / runs extremely slow
**************************************************************************************************************

INSTALLATION:
- Copy the Content from the "GameDir" folder inside your JA2 1.13 Installation directory and override any existing files!


*** STEP 1: Change game to windowed mode ***
1. Edit the 'Ja2.ini' file in your Jagged Alliance 2 v1.13 Installation directory
   -> Set SCREEN_MODE_WINDOWED = 1
   -> Set PLAY_INTRO = 0, save and close the file
2. Right click on the JA2 1.13 executable (ja2.exe), edit the properties and check the "Compatibility" mode
   -> Check the "Reduced color mode" to 16-bit


*** STEP 2: Apply a Windows 8 / Windows 10 Registry Fix ***
1. Edit the "Win8RegistryFix.reg" file inside your JA2 1.13 installation directory with notepad and change the path to the ja2.exe file
2. Save and close the file
3. Double click the "Win8RegistryFix.reg" file to alter the Windows 8 / Windows 10 Registry


*** STEP 3: Set processor affinity for "ja2.exe" to only ONE CPU (CPU 0) ***
1. Check out the step-by-step instructions on how to set the processor affinity for Windows 8 / Windows 10:
   -> http://www.eightforums.com/tutorials/24086-processor-affinity-set-applications-windows-8-a.html


*** STEP 4: Run the game in Compatibility Mode ***
1. Run the game (ja2.exe) as Windows 8 / Windows 10 Administrator
   -> Right click on the JA2 1.13 executable (ja2.exe), edit the properties and check the "Compatibility" mode
   -> Check the "XP SP3" compatibility mode


Additionalal References:
http://www.ja-galaxy-forum.com/board/ubbthreads.php/topics/312897/Jagged_Alliance_2_on_Windows_8.html
http://www.bears-pit.com/board/ubbthreads.php/topics/315860/Win_8.html#Post315860
http://www.ja-galaxy-forum.com/ubbthreads.php/topics/335812/1