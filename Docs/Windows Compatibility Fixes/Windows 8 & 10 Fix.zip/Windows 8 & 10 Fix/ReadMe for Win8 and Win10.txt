***********************************************************************************************************************
Apply the fixes if you play Jagged Alliance 2 v1.13 on Windows 8/8.1 or Windows 10 does not start / runs extremely slow
***********************************************************************************************************************

INSTALLATION:
*** STEP 1: Temporary extract the patch/fix files ***
- Extract the "Windows 8 & 10 Fix.zip" file to a temporary folder (e.g: C:\Temp\JA2_Fix)

*** STEP 2: Apply the patch/fix files ***
- Copy the following files from the temporary folder (e.g: C:\Temp\JA2_Fix\GameDir) in your JA2 1.13 Installation directory and override any existing files
-> ddraw.dll
-> libwine.dll
-> wined3d.dll
-> Win8_10_FullScreen_RegistryFix.reg
-> Win8_10_WindowedMode_RegistryFix.reg

*** STEP 3: Apply the 2 registry (*.reg) files ***
- Before applying the 2 registry files, open them with a text editor (e.g: notepad) and change the default path to the 1.13 executable ("C:\\games\\ja2\\ja2.exe") to your JA2 1.13 Installation directory and executable file
- Save the 2 registry files
- Apply the 2 regitry files by executing them

*** STEP 4: Disable the JA2 intro ***
- Open the "Ja2.ini" file with a text editor (e.g: notepad) in your Jagged Alliance 2 v1.13 Installation directory
- Search for PLAY_INTRO and change it to PLAY_INTRO = 0
- Save the file and close it

*** STEP 5 (optional): Set the game to "Windowed Mode" to play JA2 1.13 in Windowed Mode ***
- Open the "Ja2.ini" file with a text editor (e.g: notepad) in your Jagged Alliance 2 v1.13 Installation directory
- Seach for SCREEN_MODE_WINDOWED and set it to SCREEN_MODE_WINDOWED = 1
- Save the file and close it
- Right click on the JA2 1.13 executable (ja2.exe), edit the properties and check the "Compatibility" mode
   -> Check the "Reduced color mode" to 16-bit
- Set your Windows Desktop Color Schema to 16 Bit (instead of 32 Bit).
   -> Screen Resolution -> Advanced Settings -> Monitor -> Colors -> "High Color (16 bit)
 
*** STEP 6: Set processor affinity for "ja2.exe" to only ONE CPU (CPU 0) ***
- Check out the step-by-step instructions on how to set the processor affinity for Windows 8 / Windows 10:
   -> http://www.eightforums.com/tutorials/24086-processor-affinity-set-applications-windows-8-a.html

*** STEP 7: Run the game in Compatibility Mode ***
- Run the game (ja2.exe) as Windows 8 / Windows 10 Administrator
   -> Right click on the JA2 1.13 executable (ja2.exe), edit the properties and check the "Compatibility" mode
   -> Check the "XP SP3" compatibility mode
