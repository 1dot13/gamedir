Merc Profiles Editor 2.0 Beta 2 by Jazz - 2012-2013


* Wersja Beta 2

Mo�liwo�ci :
- obs�uga JA2 v1.13 oraz UB 1.13
- Operacje na plikach xml :
  -- TableData\MercProfiles.xml (odczyt, zapis, edycja, brak edycji imion)
  -- TableData\MercAvailability.xml (odczyt, edycja)
  -- TableData\MercOpinions.xml (odczyt, zapis, edycja)
  -- TableData\MercQuote.xml (odczyt, zapis, edycja)
  -- TableData\MercStartingGear.xml (odczyt, zapis, edycja)
  -- TableData\AIMAvailability.xml (odczyt, zapis, edycja)
  -- TableData\CivGroupNames.xml (odczyt, zapis)
  -- TableData\Vehicles.xml (odczyt, zapis, edycja, brak edycji nazw)
  -- TableData\IMPPortraits.xml (odczyt, zapis)
  -- TableData\Email\EmailMercAvailable.xml (odczyt, zapis)
  -- TableData\Email\EmailMercLevelUp.xml (odczyt, zapis)
  -- TableData\RandomStats.xml (odczyt, zapis, edycja)
  -- TableData\Email\EmailSenderNameList.xml (odczyt, zapis)
  -- TableData\OldAIMArchive.xml (odczyt, zapis)
  -- TableData\RPCFacesSmall.xml (brak ob�ugi pliku)
  -- TableData\SoundsProfiles.xml (odczyt, zapis, edycja)
  -- TableData\HiddenNames.xml (odczyt, zapis, edycja)
  -- TableData\NPCInventory\DevinInventory.xml (odczyt, zapis)
  -- TableData\NPCInventory\PerkoInventory.xml (odczyt, zapis)
  -- TableData\NPCInventory\TonyInventory.xml (odczyt, zapis)
  -- TableData\NPCInventory\FrankInventory.xml (odczyt, zapis)
  -- TableData\NPCInventory\MickeyInventory.xml (odczyt, zapis)
  -- TableData\NPCInventory\GabbyInventory.xml (odczyt, zapis)
  -- TableData\NPCInventory\ElginInventory.xml (odczyt, zapis)
  -- TableData\NPCInventory\JakeInventory.xml (odczyt, zapis)
  -- TableData\NPCInventory\FranzInventory.xml (odczyt, zapis)
  -- TableData\NPCInventory\HowardInventory.xml (odczyt, zapis)
  -- TableData\NPCInventory\SamInventory.xml (odczyt, zapis)
  -- TableData\NPCInventory\ArnieInventory.xml (odczyt, zapis)
  -- TableData\NPCInventory\FredoInventory.xml (odczyt, zapis)
  -- TableData\NPCInventory\KeithInventory.xml (odczyt, zapis)
  -- TableData\NPCInventory\HerveInventory.xml (odczyt, zapis)
  -- TableData\NPCInventory\PeterInventory.xml (odczyt, zapis)
  -- TableData\NPCInventory\AlbertoInventory.xml (odczyt, zapis)
  -- TableData\NPCInventory\CarloInventory.xml (odczyt, zapis)
  -- TableData\NPCInventory\MannyInventory.xml (odczyt, zapis)
- zapis plik�w lokalizacyjnych
- tworzenie nowego projektu

*********************************************************************************

Zmiany:

* Wersja Beta 2

   - naprawiono poruszanie si� pomi�dzy rekordami w oknie "Edycja"

Do zrobienia :

- przyciski w g��wnym oknie programu : kopiuj, wytnij, wklej, skasuj, biblioteka i kreator
- przyciski w oknie IMP : Add i Delete
- przeniesienie cz�� tekst�w z kodu programu, do plik�w lokalizacyjnych XML
- edycja imion
- edycja pliku IMPPortraits.xml
- edycja inwentarza sklepikarzy
- edycja wszystkich e-maili
- edycja nazw nadawc�w e-maili
- edycja biografii starych najemnik�w
- edycja nazw oraz pozosta�ych element�w grup
- edycji nazw oraz pozosta�ych element�w pojazd�w
- edycja pliku TableData\RPCFacesSmall.xml
- edycja pliku TableData\Merchants.xml
- edycja plik�w TableData\AdditionalDealer_1_Inventory.xml ... AdditionalDealer_20_Inventory.xml
